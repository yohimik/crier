#!/bin/sh
set -eu
run=/validation
export TINYGOROOT="$run/linux/tinygo"
export PATH="$TINYGOROOT/bin:$PATH"
export GOMAXPROCS=2 GOMEMLIMIT=6GiB GOTOOLCHAIN=local CGO_ENABLED=0
export GOPATH=/go GOFLAGS=-p=2
unset GOWORK GOOS GOARCH
mkdir -p "$run/bin" "$run/logs"
apt-get update > "$run/logs/linux-packages-debian.log" 2>&1
DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends ffmpeg > "$run/logs/linux-install-debian.log" 2>&1
tinygo version
go version
ffmpeg -version | head -1
cd /candidate
for probe in spawnprobe sigprobe netprobe; do
  timeout -s KILL 600 tinygo build -p 2 -o "$run/bin/$probe-linux" "./tests/$probe" > "$run/logs/build-$probe-linux.log" 2>&1
done
timeout -s KILL 180 "$run/bin/spawnprobe-linux" > "$run/logs/spawn-linux.log" 2>&1
timeout -s KILL 180 "$run/bin/sigprobe-linux" > "$run/logs/signal-linux.log" 2>&1
timeout -s KILL 600 tinygo build -p 2 -o "$run/bin/cookiejar-linux" testdata/cookiejar.go > "$run/logs/build-cookiejar-linux.log" 2>&1
timeout -s KILL 30 "$run/bin/cookiejar-linux" > "$run/logs/cookiejar-linux.log" 2>&1
timeout -s KILL 600 tinygo test -p 2 -v os > "$run/logs/os-linux.log" 2>&1
timeout -s KILL 600 tinygo test -p 2 -v net > "$run/logs/net-tests-linux.log" 2>&1
for layer in tcp tls http https dns; do
  timeout -s KILL 45 "$run/bin/netprobe-linux" "$layer" > "$run/logs/net-$layer-linux.log" 2>&1
done
cd /crier
v=github.com/yohimik/crier/internal/version
stamp="-X $v.Version=0.0.0-spike -X $v.Commit=7edaff931ac9 -X $v.Date=2026-09-05T00:00:00Z"
timeout -s KILL 1200 tinygo build -p 2 -opt=z -no-debug -tags noasm -interp-timeout=15m -ldflags "$stamp" -o "$run/bin/crier-linux-arm64" ./cmd/crier > "$run/logs/build-crier-linux.log" 2>&1
timeout -s KILL 30 "$run/bin/crier-linux-arm64" --version > "$run/logs/crier-version-linux.log" 2>&1
wc -c "$run/bin/crier-linux-arm64"
sha256sum "$run/bin/crier-linux-arm64"
CRIER_E2E_BINARY="$run/bin/crier-linux-arm64" timeout -s KILL 660 go test -p 2 -tags e2e ./test/e2e -count=1 -timeout 10m -v > "$run/logs/crier-e2e-linux.log" 2>&1
