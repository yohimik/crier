# Candidate artifact validation

TinyGo source is e7d34c8c126e0eecd2ce711915f2f88d112d833a. Net pin is 0f460803c832e5edad095ce02731f1000496dd88. Fork PR18 has 24 passing checks. Linux run33944102078 and macOS run33944102124 both report this exact head and success.

The toolchain prints 0.43.0-net.1 because this branch does not change the version constant. These are CI artifacts, not the published 0.43.0-net.1 release. No compiler or runtime source overlay is applied.

| Platform | Artifact ID | SHA-256 of downloaded tarball |
| --- | --- | --- |
| Darwin arm64 | 9963062852 | 6dc79e53c22328d6832bbe3ecd143acce0d0d04e892004b9228efbd0fc3b9788 |
| Linux arm64 | 9962890989 | f81dc83c6660295824dee9f918c5234fcc5fb4af61997e45d66f27d1dfcc5211 |

Both hashes match the Actions API digest. Workflow upload-artifact v7 uses archive:false. gh run download could not read these direct tarballs as ZIP files. Raw gh api downloads preserved their content and passed the hash check.

Compiler executable hashes are Darwin 2aae81d4e06306a4b4388b4276775877b79ec6782d88e3425a3a0c28a0d914b8 and Linux b3cf96a79581ea563253b4e8fa6b70aadcb403a62626ac663fde385121f00582.

Darwin uses Go1.26.7 and LLVM22.1.4. Linux uses Go1.26.6 and LLVM22.1.4 in golang@sha256:26326682769ca980f8f1d3b1f52be2dd1c1d25270e3de3fe0c97d6bb65df3556, with FFmpeg7.1.5. Container name is tinygo-e7d34c8c-debian-validation. Limits are 2 CPUs, 10GiB memory and swap, 2 build workers, and 6GiB Go heap. Each build and test has an external timeout.

An earlier owned Alpine container could not start the Linux compiler because its glibc interpreter was absent. No candidate test ran there. It exited and was removed by its own --rm option. The separate failproxy and verdaccio containers were not touched.

Crier source files match 7edaff931ac9367734d806b684389b3ba4caf026. The comparison worktree is read-only in the Linux container. All new artifacts and logs stay in this temporary directory. The original comparison evidence is unchanged.

Darwin focused checks pass: 16 spawn cases, 11 signal cases, cookiejar secure-cookie refusal, full os package0.754s including remapping and both fcntl argument tests. TCP, TLS1.3 with cipher4867, HTTP200, HTTPS200, and DNS not-found probes pass. TLS probe uses explicit PEM roots on Darwin.

Crier Linux arm64 E2E passed 143 cases, failed0, skipped0, exit0, in95.029s. Darwin arm64 passed142, failed0, skipped1, exit0, in73.914s. The skip is TestPublishOverTLSVerifiesThePlatform because the Go test driver does not use SSL_CERT_FILE on Darwin. Startup is fixed. The separate native Darwin TLS matrix passed trusted name and IP, refused an untrusted CA and plaintext, updated to a Go1.1.0 target with the original TinyGo backup, and rolled back offline. Restored bytes match the original. Server logs record completed handshakes and ClientHello bytes. No keychain change was made.

Linux also passed spawn16/16, signal11/11, cookiejar, full os0.078s and net0.089s, plus TCP/TLS1.3/HTTP/HTTPS/DNS probes. Darwin ephemeral port and SO_NOSIGPIPE tests passed. The Debian validation container exited0 and removed itself. Only failproxy and verdaccio remained running.

New Crier binaries are unstripped. Darwin is25,573,008 bytes, SHA256 5cfb92b18654703ac9374a35ab63c1db430e4b42e10de40f3da0ad8a7dcf73e1. Linux is29,101,552 bytes, SHA256 33f76511fa432b4d995452975a163b25fb4dbdda8846d87504632a14719524cd. These do not replace the original stripped size comparison.

No new pixel comparison, amd64 execution, or Dispat acceptance was run here. No TinyGo fork release was published. WaitDelay, full descriptor lifetime, in-flight deadline changes, and the prior render differences remain open. The TLS overlap5635/5645 still needs its owner's response. Do not infer general Go compatibility or release approval from these checks.
