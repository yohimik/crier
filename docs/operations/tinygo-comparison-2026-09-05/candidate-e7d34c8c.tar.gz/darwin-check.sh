#!/bin/sh
set -eu
run=/private/tmp/tinygo-candidate-e7d34c8c.PiviTx
export TINYGOROOT="$run/darwin/tinygo"
export PATH="$TINYGOROOT/bin:/Users/yohimik/.cache/tinygo-spike-darwin/go/bin:$PATH"
export GOPATH=/Users/yohimik/.cache/tinygo-spike-darwin/gopath
export GOMAXPROCS=2 GOMEMLIMIT=8GiB GOTOOLCHAIN=local CGO_ENABLED=0
unset GOFLAGS GOWORK GOOS GOARCH
cd /Users/yohimik/Projects/tinygo-net-next-integration
tinygo version
go version
mkdir -p "$run/bin" "$run/logs"
for probe in spawnprobe sigprobe netprobe; do
  python3 "$run/bounded.py" 600 tinygo build -p 2 -o "$run/bin/$probe-darwin" "./tests/$probe" > "$run/logs/build-$probe-darwin.log" 2>&1
done
python3 "$run/bounded.py" 180 "$run/bin/spawnprobe-darwin" > "$run/logs/spawn-darwin.log" 2>&1
python3 "$run/bounded.py" 180 "$run/bin/sigprobe-darwin" > "$run/logs/signal-darwin.log" 2>&1
python3 "$run/bounded.py" 600 tinygo build -p 2 -o "$run/bin/cookiejar-darwin" testdata/cookiejar.go > "$run/logs/build-cookiejar-darwin.log" 2>&1
python3 "$run/bounded.py" 30 "$run/bin/cookiejar-darwin" > "$run/logs/cookiejar-darwin.log" 2>&1
python3 "$run/bounded.py" 600 tinygo test -p 2 -v os > "$run/logs/os-darwin.log" 2>&1
for layer in tcp tls http https dns; do
  python3 "$run/bounded.py" 45 "$run/bin/netprobe-darwin" "$layer" > "$run/logs/net-$layer-darwin.log" 2>&1
done
printf '%s\n' 'Darwin probe commands completed'
