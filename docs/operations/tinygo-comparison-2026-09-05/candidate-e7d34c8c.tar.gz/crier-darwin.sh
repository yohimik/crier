#!/bin/sh
set -eu
run=/private/tmp/tinygo-candidate-e7d34c8c.PiviTx
export TINYGOROOT="$run/darwin/tinygo"
export PATH="$TINYGOROOT/bin:/Users/yohimik/.cache/tinygo-spike-darwin/go/bin:/opt/homebrew/bin:$PATH"
export GOPATH=/Users/yohimik/.cache/tinygo-spike-darwin/gopath
export GOMAXPROCS=2 GOMEMLIMIT=8GiB GOTOOLCHAIN=local CGO_ENABLED=0
unset GOFLAGS GOWORK GOOS GOARCH
cd /Users/yohimik/Projects/crier-size-comparison
git diff --quiet 7edaff931ac9367734d806b684389b3ba4caf026 -- cmd internal go.mod go.sum announce examples test
mkdir -p "$run/bin" "$run/logs"
v=github.com/yohimik/crier/internal/version
stamp="-X $v.Version=0.0.0-spike -X $v.Commit=7edaff931ac9 -X $v.Date=2026-09-05T00:00:00Z"
python3 "$run/bounded.py" 1200 /usr/bin/time -l tinygo build -p 2 -opt=z -no-debug -tags noasm -interp-timeout=15m -ldflags "$stamp" -o "$run/bin/crier-darwin-arm64" ./cmd/crier > "$run/logs/build-crier-darwin.log" 2>&1
python3 "$run/bounded.py" 30 "$run/bin/crier-darwin-arm64" --version > "$run/logs/crier-version-darwin.log" 2>&1
wc -c "$run/bin/crier-darwin-arm64"
shasum -a 256 "$run/bin/crier-darwin-arm64"
CRIER_E2E_BINARY="$run/bin/crier-darwin-arm64" python3 "$run/bounded.py" 660 go test -p 2 -tags e2e ./test/e2e -count=1 -timeout 10m -v > "$run/logs/crier-e2e-darwin.log" 2>&1
