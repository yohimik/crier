#!/bin/sh
set -eu
run=/private/tmp/tinygo-candidate-e7d34c8c.PiviTx
export PATH=/Users/yohimik/.cache/tinygo-spike-darwin/go/bin:/opt/homebrew/bin:$PATH
export GOPATH=/Users/yohimik/.cache/tinygo-spike-darwin/gopath GOMAXPROCS=2 GOTOOLCHAIN=local CGO_ENABLED=0
unset GOOS GOARCH GOWORK GOFLAGS
cd /Users/yohimik/Projects/crier-size-comparison
go build -p 2 -o "$run/bin/sufake-darwin" ./coverage/size-comparison/sufake/main.go
go build -p 2 -ldflags '-X github.com/yohimik/crier/internal/version.Version=1.1.0' -o "$run/bin/update-darwin-arm64" ./cmd/crier
work=$(mktemp -d "$run/tls-darwin.XXXXXX")
server=
trap 'if [ -n "$server" ]; then kill "$server" 2>/dev/null || true; wait "$server" 2>/dev/null || true; fi' EXIT
serverlog="$run/logs/tls-server-darwin.log"
"$run/bin/sufake-darwin" -addr 127.0.0.1:0 -ca "$work/ca.pem" -asset "$run/bin/update-darwin-arm64" -asset-name crier-darwin-arm64 -version 1.1.0 > "$serverlog" 2>&1 &
server=$!
i=0
until grep -q 'sufake: ca' "$serverlog"; do
  i=$((i+1))
  [ "$i" -lt 100 ] || exit 1
  sleep 0.1
done
base=$(sed -n 's/^sufake: listening //p' "$serverlog")
cp "$run/bin/crier-darwin-arm64" "$work/crier"
bin="$work/crier"
check() {
  label=$1 expected=$2
  shift 2
  code=0
  python3 "$run/bounded.py" 90 "$@" > "$work/row.log" 2>&1 || code=$?
  printf '%s exit=%s expected=%s\n' "$label" "$code" "$expected"
  cat "$work/row.log"
  [ "$code" -eq "$expected" ]
}
check trusted-name 1 env SSL_CERT_FILE="$work/ca.pem" "$bin" self-update --api-url "$base" --check
grep -q '1.1.0' "$work/row.log"
check trusted-ip 1 env SSL_CERT_FILE="$work/ca.pem" "$bin" self-update --api-url "https://127.0.0.1:${base##*:}" --check
grep -q '1.1.0' "$work/row.log"
code=0
python3 "$run/bounded.py" 90 env SSL_CERT_FILE=/dev/null SSL_CERT_DIR="$work/no-roots" "$bin" self-update --api-url "$base" --check > "$work/row.log" 2>&1 || code=$?
printf 'untrusted exit=%s\n' "$code"
cat "$work/row.log"
[ "$code" -ne 0 ] && [ "$code" -ne 124 ]
grep -Eq 'certificate|x509' "$work/row.log"
code=0
python3 "$run/bounded.py" 90 "$bin" self-update --api-url "http://localhost:${base##*:}" --check > "$work/row.log" 2>&1 || code=$?
printf 'plaintext exit=%s\n' "$code"
cat "$work/row.log"
[ "$code" -ne 0 ] && [ "$code" -ne 124 ]
check full-update 0 env SSL_CERT_FILE="$work/ca.pem" "$bin" self-update --api-url "$base"
"$bin" --version > "$work/version.log"
grep -q '^crier 1.1.0 ' "$work/version.log"
cat "$work/version.log"
"$bin.backup" --version > "$work/backup-version.log"
grep -q '^crier 0.0.0-spike ' "$work/backup-version.log"
cat "$work/backup-version.log"
kill "$server"
wait "$server" 2>/dev/null || true
server=
check rollback 0 "$bin" self-update --rollback
"$bin" --version > "$work/rollback-version.log"
grep -q '^crier 0.0.0-spike ' "$work/rollback-version.log"
cmp "$bin" "$run/bin/crier-darwin-arm64"
cat "$work/rollback-version.log"
grep -q 'handshake=true' "$serverlog"
grep -q 'clienthello=true' "$serverlog"
grep -q 'clienthello=false' "$serverlog"
printf '%s\n' 'TLS matrix passed'
